package com.example.anuradha.new_driver;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class Destination extends AppCompatActivity {
    ListView l1;
    String text[]={"Name","Name","Name"};
    String text2[]={"Source","Source","Source"};
    String text3[]={"Destination","Destination","Destination"};
    Integer image[]={R.drawable.whatsapp,R.drawable.whatsapp,R.drawable.whatsapp};
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination);
        l1= (ListView) findViewById(R.id.lg);
        b1= (Button) findViewById(R.id.button6);
        CustomAdapter1 adapter=new CustomAdapter1(this,text,text2,text3,image);
        l1.setAdapter(adapter );
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Destination.this,Fourth_Activity.class);
                startActivity(i);
            }
        });
    }
}
