package com.example.anuradha.new_driver;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Otp1 extends AppCompatActivity {
    public Button b2;
    public void init()
    {

        b2= (Button)findViewById(R.id.button4);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent toy1 = new Intent(Otp1.this,Second_Activity.class);
                startActivity(toy1);
            }
        });

    /*    b3= (Button)findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent toy2 = new Intent(otp1.this, Maps.class);
                startActivity(toy2);
            }
        });
*/
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp1);
        init();
    }
}
