package com.example.anuradha.new_driver;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//package com.example.shikharagarwal.abcd;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//import static com.example.anuradha.new_driver.R.id.tg4;


public class MainActivity extends AppCompatActivity {
    TextView tg3;
    Button b1;

    EditText e1,e2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        //t3= (TextView) findViewById(R.id.tg3);
        tg3 = (TextView)findViewById(R.id.tg3);
      //  tg4 = (TextView)findViewById(R.id.tg4);
        e1= (EditText) findViewById(R.id.eg1);
//        e2= (EditText) findViewById(R.id.eg2);
        b1= (Button) findViewById(R.id.button3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Otp1.class);
                startActivity(i);
            }
        });
      /*  t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/
        tg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ForgetPassword.class);
                startActivity(intent);
            }
        });
     /*   tg4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Getotp1.class);
                startActivity(intent);
            }
        });
*/
    }
}
