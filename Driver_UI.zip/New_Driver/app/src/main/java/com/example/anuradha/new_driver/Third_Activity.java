package com.example.anuradha.new_driver;



        import android.app.DatePickerDialog;
        import android.app.Dialog;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.DatePicker;
        import android.widget.EditText;

public class Third_Activity extends AppCompatActivity{

    EditText from,to;
    int year_x,month_x,day_x;
    static final int DIALOG_ID1 = 0;
    static final int DIALOG_ID2 = 1;
    Button btn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_);
        showDialogOnButtonClick();
        btn = (Button)findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Third_Activity.this,Fifth_Activity.class);
                startActivity(i);
            }
        });
    }
    public void showDialogOnButtonClick()
    {
        from = (EditText) findViewById(R.id.editText);
        to = (EditText) findViewById(R.id.editText2);
        from.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DIALOG_ID1);

            }
        });
        to.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DIALOG_ID2);

            }
        });
    }


    protected Dialog onCreateDialog(int id)
    {
        if(id == DIALOG_ID1)
            return new DatePickerDialog(this,dpickerListener1,year_x,month_x,day_x);
        else if(id == DIALOG_ID2)
            return new DatePickerDialog(this,dpickerListener2,year_x,month_x,day_x);
        return null;
    }

    private DatePickerDialog.OnDateSetListener dpickerListener1 = new DatePickerDialog.OnDateSetListener()
    {
        public void onDateSet(DatePicker view,int year,int monthOfYear,int dayOfMonth)
        {
            year_x = year;
            month_x = monthOfYear;
            day_x = dayOfMonth;
            String date = day_x + "-" + (month_x + 1) + "-" + year_x;

            from.setText(date);
            //to.setText(date);
        }
    };

    private DatePickerDialog.OnDateSetListener dpickerListener2 = new DatePickerDialog.OnDateSetListener()
    {
        public void onDateSet(DatePicker view,int year,int monthOfYear,int dayOfMonth)
        {
            year_x = year;
            month_x = monthOfYear;
            day_x = dayOfMonth;
            String date = day_x + "-" + (month_x + 1) + "-" + year_x;

            to.setText(date);
            //to.setText(date);
        }
    };
}